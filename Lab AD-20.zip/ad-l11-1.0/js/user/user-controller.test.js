const UserController = require("./user-controller");
const User = require("./user");

const userController = new UserController();

test('add user to userController', () => {    
    let user = new User(1234,"Santiago", "santiago@generation.org");
    userController.add(user);    
    expect(userController.getUsers()).toContain(user);
  });

test('remove user to userController', () => {    
    let user = new User(1234,"Santiago", "santiago@generation.org");
    userController.add(user);    
    userController.remove(user);
    expect(userController.users).not.toContain(user);
  });

  ////Prueba de add con usuario que no esta en la lista
  test('add a user not in the list', () => {    
    let newUser = new User(2691,"Erika", "erika@generation.org");
    expect(userController.getUsers()).not.toContain(newUser);
    userController.add(newUser);
    expect(userController.getUsers()).toContain(newUser);
  });

  ////Prueba de remove con usuario que no esta en la lista
  test('remove a user not in the list', () => {    
    let UsurionoExiste = new User(8532,"Esme", "esme@generation.org");
    userController.remove(UsurionoExiste);
    expect(userController.getUsers()).not.toContain(UsurionoExiste);
  });

  ////Prueba de findByEmail().
  test('find user by email', () => {    
    let email = new User (1234, "Santiago", "santiago@generation.org");
    userController.add(email);
    expect(userController.findByEmail("santiago@generation.org")).toBe(email);
  });

  test('find user by no-existing email', () => {
    expect(userController.findByEmail("correo@generation.org")).toBeUndefined();
  });

  ////Prueba de findById().
  test('find user by id', () => {    
    let id = new User (1234, "Santiago", "santiago@generation.org");
    userController.add(id);
    expect(userController.findById(1234)).toBe(id);
  });

  test('find user by no-existing id', () => {
    expect(userController.findById(1596)).toBeUndefined();
  } );

